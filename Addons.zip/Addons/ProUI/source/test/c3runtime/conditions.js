"use strict";

{
	C3.Behaviors.MyCompany_MyBehavior.Cnds =
	{
		IsMoving()
		{
			return false;		// placeholder
		}
	};
}