"use strict";

{
	C3.Behaviors.MyCompany_MyBehavior.Type = class MyBehaviorType extends C3.SDKBehaviorTypeBase
	{
		constructor(behaviorType)
		{
			super(behaviorType);
		}
		
		Release()
		{
			super.Release();
		}
		
		OnCreate()
		{	
		}
	};
}