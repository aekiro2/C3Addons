"use strict";

{
	const C3 = self.C3;
	C3.Behaviors.aekiro_translationB.Type = class aekiro_translationBType extends C3.SDKBehaviorTypeBase
	{
		constructor(behaviorType)
		{
			super(behaviorType);
		}
		
		Release()
		{
			super.Release();
		}
		
		OnCreate()
		{	
		}
	};
}
