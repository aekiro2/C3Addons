"use strict";

{
	const C3 = self.C3;
	C3.Behaviors.aekiro_translationB = class aekiro_translationBBehavior extends C3.SDKBehaviorBase
	{
		constructor(opts)
		{
			super(opts);
		}
		
		Release()
		{
			super.Release();
		}
	};
}
