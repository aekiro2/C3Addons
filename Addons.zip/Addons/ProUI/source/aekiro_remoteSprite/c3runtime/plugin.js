"use strict";
{
    const C3 = self.C3;
    C3.Plugins.aekiro_remoteSprite = class RemoteSpritePlugin extends C3.SDKPluginBase
    {
        constructor(opts)
        {
            super(opts);
        }

        Release()
        {
            super.Release();
        }
    };
}