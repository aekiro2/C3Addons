"use strict";
{
    const C3 = self.C3;
    C3.Plugins.aekiro_remoteSprite.Cnds = {

        };
}