"use strict";

{
	const C3 = self.C3;
	C3.Behaviors.aekiro_discreteProgressPart.Type = class aekiro_discreteProgressPartType extends C3.SDKBehaviorTypeBase
	{
		constructor(behaviorType)
		{
			super(behaviorType);
		}
		
		Release()
		{
			super.Release();
		}
		
		OnCreate()
		{	
		}
	};
}
