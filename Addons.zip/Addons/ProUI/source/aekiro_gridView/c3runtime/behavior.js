"use strict";

{
	const C3 = self.C3;
	C3.Behaviors.aekiro_gridView = class aekiro_gridViewBehavior extends C3.SDKBehaviorBase
	{
		constructor(opts)
		{
			super(opts);
		}
		
		Release()
		{
			super.Release();
		}
	};
}
