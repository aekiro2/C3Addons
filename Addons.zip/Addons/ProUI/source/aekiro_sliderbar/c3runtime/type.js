"use strict";

{
	const C3 = self.C3;
	C3.Behaviors.aekiro_sliderbar.Type = class aekiro_sliderbarType extends C3.SDKBehaviorTypeBase
	{
		constructor(behaviorType)
		{
			super(behaviorType);
		}
		
		Release()
		{
			super.Release();
		}
		
		OnCreate()
		{	
		}
	};
}
