"use strict";

{
	const C3 = self.C3;
	C3.Behaviors.aekiro_radiogroup = class aekiro_radiogroupBehavior extends C3.SDKBehaviorBase
	{
		constructor(opts)
		{
			super(opts);
		}
		
		Release()
		{
			super.Release();
		}
	};
}
