"use strict";

{
	const C3 = self.C3;
	C3.Plugins.aekiro_proui.Type = class aekiro_prouiSingleGlobalType extends C3.SDKTypeBase
	{
		constructor(objectClass)
		{
			super(objectClass);
		}
		
		Release()
		{
			super.Release();
		}
		
		OnCreate()
		{	
		}
	};
}
