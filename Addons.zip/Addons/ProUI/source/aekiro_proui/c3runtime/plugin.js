"use strict";

{
	const C3 = self.C3;
	C3.Plugins.aekiro_proui = class aekiro_prouiSingleGlobalPlugin extends C3.SDKPluginBase
	{
		constructor(opts)
		{
			super(opts);
		}
		
		Release()
		{
			super.Release();
		}
	};
}
