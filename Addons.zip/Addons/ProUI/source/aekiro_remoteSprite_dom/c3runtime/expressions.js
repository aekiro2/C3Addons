"use strict";
{
    C3.Plugins.aekiro_remoteSprite.Exps = {

        };
}