"use strict";

{
	const C3 = self.C3;
	C3.Behaviors.aekiro_radiobutton.Cnds =
	{
	};
	Object.assign(C3.Behaviors.aekiro_radiobutton.Cnds, globalThis.Aekiro.button.Cnds);
}
