"use strict";

{
	self.C3.Behaviors.aekiroWater.Cnds =
	{
		IsMoving()
		{
			return false;		// placeholder
		}
	};
}