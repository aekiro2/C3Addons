"use strict";

{
	const C3 = self.C3;

	C3.Behaviors.aekiroWater.Type = class aekiroWater_SDKBehaviorTypeBase extends C3.SDKBehaviorTypeBase
	{
		constructor(behaviorType)
		{
			super(behaviorType);
		}
		
		Release()
		{
			super.Release();
		}
		
		OnCreate()
		{	
		}
	};
}