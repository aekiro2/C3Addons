"use strict";

{
	const C3 = self.C3;

	C3.Behaviors.aekiroWater = class aekiroWater_SDKBehaviorBase extends C3.SDKBehaviorBase
	{
		constructor(opts)
		{
			super(opts);
		}
		
		Release()
		{
			super.Release();
		}
	};
}